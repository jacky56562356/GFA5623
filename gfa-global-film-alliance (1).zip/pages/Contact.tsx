
import React, { useState } from 'react';
import SectionHeading from '../components/ui/SectionHeading';
// Fix: Import useLocale from LocaleContext.tsx instead of App.tsx
import { useLocale } from '../LocaleContext.tsx';

const Contact: React.FC = () => {
  const { t } = useLocale();
  const [formType, setFormType] = useState<'Individual' | 'Organization' | 'Merchant'>('Individual');

  const types = [
    { id: 'Individual', label: t.contact.labels.individual },
    { id: 'Organization', label: t.contact.labels.organization },
    { id: 'Merchant', label: t.contact.labels.merchant }
  ];

  const merchantCats = t.locale === 'zh' 
    ? ['法律服务', '保险', '餐饮', '零售', '旅行', '制作服务']
    : ['Legal', 'Insurance', 'Dining', 'Retail', 'Travel', 'Production Services'];

  const orgTypes = t.locale === 'zh'
    ? ['制片公司', '电影学校 / 机构', '电影节 / 活动方', '政府 / 非营利组织']
    : ['Production Agency', 'Film School / Institution', 'Festival / Event Body', 'Government / NGO'];

  return (
    <div className="py-32 max-w-7xl mx-auto px-4">
      <SectionHeading title={t.contact.title} subtitle={t.contact.intro} />
      
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-12">
        <div className="lg:col-span-1 space-y-12">
          <div className="flex flex-col gap-4">
            {types.map((type) => (
              <button 
                key={type.id}
                onClick={() => setFormType(type.id as any)}
                className={`text-left p-6 border-l-4 transition-all uppercase text-xs font-black tracking-widest ${formType === type.id ? 'bg-gfa-gold/10 border-gfa-gold text-gfa-gold' : 'bg-gfa-darkGray/30 border-white/5 text-gfa-gray hover:text-white'}`}
              >
                {type.label} {t.contact.labels.join}
              </button>
            ))}
          </div>
          
          <div className="pt-12 border-t border-white/5 space-y-8">
            <div>
              <h4 className="text-white font-black uppercase text-[10px] tracking-widest mb-2">{t.contact.labels.inquiries}</h4>
              <p className="text-gfa-gold font-bold">general@gfa-alliance.org</p>
            </div>
            <div>
              <h4 className="text-white font-black uppercase text-[10px] tracking-widest mb-2">{t.contact.labels.press}</h4>
              <p className="text-gfa-gold font-bold">media@gfa-alliance.org</p>
            </div>
          </div>
        </div>

        <div className="lg:col-span-3 bg-gfa-darkGray p-10 md:p-16 border border-white/5 shadow-2xl">
          <h3 className="text-3xl font-black mb-12 uppercase tracking-tight">
            {t.contact.form.header.replace('{type}', types.find(it => it.id === formType)?.label || '')}
          </h3>
          
          <form className="space-y-8" onSubmit={(e) => { e.preventDefault(); alert(t.locale === 'zh' ? '申请已提交至 GFA 注册处' : 'Application submitted to GFA Registry.'); }}>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-3">
                <label className="text-[10px] text-gfa-gold uppercase font-black tracking-widest">{t.contact.form.name}</label>
                <input required type="text" className="w-full bg-gfa-black border border-white/20 p-4 text-white focus:outline-none focus:border-gfa-gold transition-colors" />
              </div>
              <div className="space-y-3">
                <label className="text-[10px] text-gfa-gold uppercase font-black tracking-widest">{t.contact.form.email}</label>
                <input required type="email" className="w-full bg-gfa-black border border-white/20 p-4 text-white focus:outline-none focus:border-gfa-gold transition-colors" />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-3">
                <label className="text-[10px] text-gfa-gold uppercase font-black tracking-widest">{t.contact.form.location}</label>
                <input required type="text" className="w-full bg-gfa-black border border-white/20 p-4 text-white focus:outline-none focus:border-gfa-gold transition-colors" />
              </div>
              {formType === 'Merchant' && (
                <div className="space-y-3">
                  <label className="text-[10px] text-gfa-gold uppercase font-black tracking-widest">{t.contact.form.cat}</label>
                  <select className="w-full bg-gfa-black border border-white/20 p-4 text-white focus:outline-none focus:border-gfa-gold">
                    {merchantCats.map(c => <option key={c}>{c}</option>)}
                  </select>
                </div>
              )}
              {formType === 'Organization' && (
                <div className="space-y-3">
                  <label className="text-[10px] text-gfa-gold uppercase font-black tracking-widest">{t.contact.form.orgType}</label>
                  <select className="w-full bg-gfa-black border border-white/20 p-4 text-white focus:outline-none focus:border-gfa-gold">
                    {orgTypes.map(o => <option key={o}>{o}</option>)}
                  </select>
                </div>
              )}
            </div>

            <div className="space-y-3">
              <label className="text-[10px] text-gfa-gold uppercase font-black tracking-widest">{t.contact.form.message}</label>
              <textarea required rows={5} className="w-full bg-gfa-black border border-white/20 p-4 text-white focus:outline-none focus:border-gfa-gold transition-colors"></textarea>
            </div>

            <div className="flex items-start gap-4 py-4">
              <input required type="checkbox" className="mt-1 w-5 h-5 accent-gfa-gold" />
              <p className="text-[10px] text-gfa-gray uppercase tracking-widest font-bold leading-relaxed">
                {t.contact.form.consent}
              </p>
            </div>

            <button type="submit" className="bg-gfa-gold text-gfa-black px-16 py-5 font-black uppercase text-xs tracking-[0.2em] hover:bg-white transition-all shadow-xl">
              {t.contact.form.submit}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Contact;
