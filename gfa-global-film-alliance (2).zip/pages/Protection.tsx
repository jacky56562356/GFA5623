import React from 'react';
import SectionHeading from '../components/ui/SectionHeading';
import { useLocale } from '../App';

const Protection: React.FC = () => {
  const { t } = useLocale();
  const pr = t.protection;

  return (
    <div className="py-32 max-w-7xl mx-auto px-4">
      <SectionHeading 
        title={pr.title} 
        subtitle={pr.subtitle} 
      />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 mb-32 items-center">
        <div>
          <h3 className="text-3xl font-black mb-8 gold-gradient uppercase tracking-tight">{pr.modelTitle}</h3>
          <p className="text-gfa-gray text-lg mb-10 leading-relaxed uppercase font-medium tracking-wider">
            {pr.modelBody}
          </p>
          <div className="space-y-4">
            {pr.modelItems.map(i => (
              <div key={i} className="flex items-center gap-4 bg-gfa-darkGray p-6 border border-white/5">
                <span className="text-gfa-gold">✓</span>
                <span className="text-sm font-black uppercase tracking-widest text-white">{i}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="relative aspect-square bg-gfa-darkGray border border-gfa-gold/20 flex items-center justify-center">
           <div className="text-center p-12">
             <div className="text-8xl mb-8">🛡️</div>
             <h4 className="text-xl font-black text-gfa-gold uppercase tracking-widest">Active Safeguards</h4>
           </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-32">
        {pr.safeguards.map((group, idx) => (
          <div key={idx} className="p-10 border border-white/5 bg-gfa-darkGray/50">
            <h4 className="text-sm font-black uppercase tracking-widest text-gfa-gold mb-6">{group.title}</h4>
            <ul className="text-[10px] text-gfa-gray space-y-3 font-bold uppercase tracking-widest">
              {group.items.map((item, i) => (
                <li key={i}>• {item}</li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Protection;